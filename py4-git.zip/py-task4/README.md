# Spam Email Classifier 

This project implements a machine learning model to classify messages as spam or not spam using Scikit-learn and Naive Bayes.

- The dataset is created within the notebook.
- Model evaluation includes accuracy, classification report, and confusion matrix.
- Sample predictions are shown on new inputs.

## How to Run
Open the Jupyter Notebook `Spam_Email_Classifier_Task4.ipynb` and run all cells.
