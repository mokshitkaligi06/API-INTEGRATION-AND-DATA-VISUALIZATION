

import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# -------------------------------------------
# CONFIGURATION
# -------------------------------------------
API_KEY = 'cd3ecf78f6585ac0fce1177dded4ca41'  # Replace with your OpenWeatherMap API key
CITY = 'Visakhapatnam'
UNITS = 'metric'  # Use 'imperial' for Fahrenheit
API_URL = f"http://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units={UNITS}"

# -------------------------------------------
# FUNCTION TO FETCH WEATHER DATA
# -------------------------------------------
def fetch_weather_data():
    try:
        response = requests.get(API_URL)
        response.raise_for_status()  # Raise error if bad request
        data = response.json()
        return data['list']
    except Exception as e:
        print("Error fetching data:", e)
        return []

# -------------------------------------------
# FUNCTION TO PROCESS DATA
# -------------------------------------------
def process_weather_data(forecast_list):
    weather_records = []
    for entry in forecast_list:
        weather_records.append({
            'datetime': entry['dt_txt'],
            'temperature': entry['main']['temp'],
            'humidity': entry['main']['humidity'],
            'weather': entry['weather'][0]['description'].title()
        })
    df = pd.DataFrame(weather_records)
    df['datetime'] = pd.to_datetime(df['datetime'])
    return df

# -------------------------------------------
# FUNCTION TO PLOT DATA
# -------------------------------------------
def plot_weather_dashboard(df):
    plt.figure(figsize=(14, 6))
    sns.lineplot(x='datetime', y='temperature', data=df, label='Temperature (°C)', color='tomato')
    sns.lineplot(x='datetime', y='humidity', data=df, label='Humidity (%)', color='steelblue')

    # Annotate with weather descriptions every 2nd entry (~6 hours)
    for i in range(0, len(df), 2):
        plt.text(df['datetime'].iloc[i], df['temperature'].iloc[i] + 1, df['weather'].iloc[i], fontsize=8, rotation=45)

    plt.title(f'5-Day Weather Forecast for {CITY}', fontsize=16)
    plt.xlabel('Date & Time')
    plt.ylabel('Value')
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.grid(True)

    # Save plot as a PNG file
    plt.savefig('weather_forecast.png', dpi=300)
    plt.show()

# -------------------------------------------
# MAIN EXECUTION
# -------------------------------------------
def main():
    print(f"Fetching weather data for {CITY}...")
    forecast_list = fetch_weather_data()

    if not forecast_list:
        print("Failed to get weather data.")
        return

    df = process_weather_data(forecast_list)
    plot_weather_dashboard(df)

if __name__ == '__main__':
    main()
