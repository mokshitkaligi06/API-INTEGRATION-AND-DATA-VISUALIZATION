import nltk
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Download punkt tokenizer (if not already done)
nltk.download('punkt')

# Combined knowledge base with simple and detailed questions
knowledge_base = {
    # Simple questions
    "hello": "Hello! How can I help you?",
    "hi": "Hi there! What can I do for you?",
    "how are you": "I'm good, thank you! How about you?",
    "what is your name": "I am your friendly chatbot.",
    "what can you do": "I can answer simple questions and chat with you.",
    "where are you from": "I live in your computer!",
    "what is python": "Python is a programming language used for many things, including AI.",
    "what is ai": "AI stands for Artificial Intelligence, which means machines that can think.",
    "what time is it": "Sorry, I can't tell the time right now.",
    "bye": "Goodbye! Have a great day!",
    "thank you": "You're welcome!",
    "help": "Sure! Ask me anything.",

    # More detailed AI-related questions
    "what is machine learning": "Machine Learning is a subset of AI that enables machines to learn from data.",
    "tell me about nlp": "Natural Language Processing enables computers to understand human language.",
    "who created you": "I was created by an intern using Python and NLP libraries.",
    "what is deep learning": "Deep Learning is a subset of machine learning involving neural networks with many layers.",
    "how does ai work": "AI works by processing data and learning patterns to make decisions or predictions.",
    "what are neural networks": "Neural networks are algorithms inspired by the human brain that help computers learn from data.",
    "what is supervised learning": "Supervised learning is a type of machine learning where models are trained on labeled data.",
    "what is unsupervised learning": "Unsupervised learning involves training models on data without labeled responses.",
    "what is reinforcement learning": "Reinforcement learning is a type of machine learning where agents learn by receiving rewards or penalties.",
    "what is a chatbot": "A chatbot is a computer program designed to simulate human conversation.",
    "how can i learn ai": "You can learn AI by studying math, programming, and using online courses and tutorials.",
    "what is data science": "Data Science is the field that uses scientific methods to extract knowledge from data.",
    "what libraries are used in ai": "Popular AI libraries include TensorFlow, PyTorch, Keras, Scikit-learn, and NLTK.",
    "what is natural language processing": "NLP is a field of AI that focuses on the interaction between computers and human language.",
    "can you help me with programming": "Yes, I can try to answer programming questions or guide you to resources.",
    "what is the difference between ai and machine learning": "AI is the broader concept of machines being intelligent, while machine learning is a technique to achieve AI.",
}

# Prepare lists for vectorization
sentences = list(knowledge_base.keys())
responses = list(knowledge_base.values())

def preprocess(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text

def chatbot_response(user_input):
    user_input = preprocess(user_input)
    sentences_processed = [preprocess(sentence) for sentence in sentences]

    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform(sentences_processed + [user_input])

    cosine_sim = cosine_similarity(vectors[-1], vectors[:-1])
    idx = cosine_sim.argsort()[0][-1]
    score = cosine_sim[0][idx]

    if score < 0.2:
        return "Sorry, I don't understand. Can you please rephrase?"
    else:
        return responses[idx]

def main():
    print("Hi! I am your AI Chatbot. Type 'quit' to exit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "quit":
            print("Chatbot: Goodbye! Have a great day.")
            break
        response = chatbot_response(user_input)
        print("Chatbot:", response)

if __name__ == "__main__":
    main()
